// server.js
const express = require("express");
const multer = require("multer");
const path = require("path");
const dotenv = require("dotenv");
const connectDB = require("./config/db.js");
const fs = require("fs");
const Application = require("./models/Application.js");
const cors = require("cors");
const archiver = require("archiver");

dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());
const PORT = process.env.PORT || 3000;

// ✅ Connect to DB
connectDB();

// ✅ Ensure base upload folder exists
const baseUploadDir = path.join(__dirname, "public/uploads");
if (!fs.existsSync(baseUploadDir)) {
  fs.mkdirSync(baseUploadDir, { recursive: true });
}

// ✅ Multer storage config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const email = req.body.email || "general";
    const userDir = path.join(baseUploadDir, email);
    fs.mkdirSync(userDir, { recursive: true });
    cb(null, userDir);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    const safeField = file.fieldname.replace(/[^a-z0-9-_]/gi, "_");
    cb(null, `${safeField}_${Date.now()}${ext}`);
  },
});

const upload = multer({ storage });

// ✅ Serve static files (for uploaded docs)
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));

// ==========================
// 📌 Fetch all applications
// ==========================
app.get("/api/applications", async (req, res) => {
  try {
    const apps = await Application.find().sort({ createdAt: -1 });
    res.json(apps);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "❌ Failed to fetch applications" });
  }
});

app.post("/api/application/:id", async (req, res) => {
  const { id } = req.params;
  const { notes = "", status = "pending-review" } = req.body;

  try {
    const application = await Application.findByIdAndUpdate(
      id, // ✅ pass ID directly
      { $set: { notes, status } }, // ✅ set both fields
      { new: true } // ✅ return updated doc
    );

    if (application) {
      return res.json({ message: "Updated successfully", application });
    } else {
      return res.status(404).json({ error: "Application not found" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error in updating application" });
  }
});


app.delete("/api/application/:id", async (req, res) => {
  const {id} = req.params;

  try {
    const application = await Application.findByIdAndDelete({ id });
    if (application) {
      res.json({ message: 'application deleted successfully' })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: 'error in deleting application' })
  }
})

app.get("/api/application/:email/:filename", (req, res) => {
  const filePath = path.join(baseUploadDir, req.params.email, req.params.filename);
  res.download(filePath); 
});

app.get("/api/application/download/", async (req, res) => {
  try {
    const email = req.query.email;
    const customerFolder = path.join(baseUploadDir, email);

    if (!fs.existsSync(customerFolder)) {
      return res.status(404).json({ message: "No files found for this user" });
    }

    res.attachment(`${email}-files.zip`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", err => { throw err; });

    archive.pipe(res);
    archive.directory(customerFolder, false);
    await archive.finalize();

    // ✅ Notice: no fs.unlink or fs.rm → original files remain
  } catch (err) {
    console.error("Error creating zip:", err);
    res.status(500).json({ message: "Server error while zipping files" });
  }
});






app.get("/api/customers/:id", async (req, res) => {
  try {
    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ message: "Application not found" });
    }

    res.json(application);
  } catch (err) {
    console.error("Error fetching application:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ==========================
// 📌 Submit / Update form
// ==========================
app.post(
  "/submit",
  upload.fields([
    { name: "aadhaar", maxCount: 1 },
    { name: "photo", maxCount: 1 },
    { name: "signature", maxCount: 1 },
    { name: "marksheet", maxCount: 1 },
    { name: "blood_group", maxCount: 1 },
    { name: "payment_screenshot", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const { first_name, last_name, email, phone, gender, payment_mode } = req.body;

      // ✅ Check existing application
      let application = await Application.findOne({ email });

      const newData = {
        first_name,
        last_name,
        email,
        phone,
        gender,
        documents: {
          aadhaar: req.files["aadhaar"]?.[0].filename || application?.documents?.aadhaar,
          photo: req.files["photo"]?.[0].filename || application?.documents?.photo,
          signature:
            req.files["signature"]?.[0].filename || application?.documents?.signature,
          marksheet:
            req.files["marksheet"]?.[0].filename || application?.documents?.marksheet,
          blood_group:
            req.files["blood_group"]?.[0].filename || application?.documents?.blood_group,
        },
        payment: {
          mode: payment_mode,
          screenshot:
            req.files["payment_screenshot"]?.[0].filename||
            application?.payment?.screenshot,
        },
      };

      if (application) {
        // ✅ Update existing
        application.set(newData);
        await application.save();
        console.log("✅ Updated:", application._id);
        return res.json({ success: true, message: "Application updated successfully" });
      } else {
        // ✅ Create new
        application = new Application(newData);
        await application.save();
        console.log(application)
        console.log("✅ Created new:", application._id);
        return res.json({ success: true, message: "Application submitted successfully" });
      }
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "❌ Error saving application" });
    }
  }
);

// ==========================
// 📌 Start Server
// ==========================
app.listen(PORT, () =>
  console.log(`🚀 Server running at http://localhost:${PORT}`)
);
